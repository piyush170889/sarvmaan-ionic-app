import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, Events } from 'ionic-angular';
import { AddMaterialListPage } from '../add-material-list/add-material-list'; 
import { ProductListPage } from '../product-list-page/product-list-page';


@IonicPage()
@Component({
  selector: 'page-add-material',
  templateUrl: 'add-material.html',
})
export class AddMaterialPage {
   uniqueId: any;
   productNameList: any = [];
   rateList: any = [];
   unitList: any = [];

   custRate:any;
   amount:any;
   notes:any;
   productName:any;
   rate:any;
   unit:any;
   materialId: any;
   quantity: any;

   editData:any = [];
   data:any;
   total: any= 0;
   perUnitRate: any;
   saveMaterialToQuotationData: any = [];
   discount: any;
   checked: any;
   disabled: boolean = false;
   editDataParams: any;
   pageName: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, private toastCtrl: ToastController,public events: Events) {
    this.uniqueId = Math.random().toString(36).substr(2, 9);
    console.log(this.uniqueId);
    this.materialId = this.uniqueId;

    console.log(this.navParams.get('pageName'))
    this.pageName = this.navParams.get('pageName');
    console.log(JSON.stringify(this.navParams.get('materialListArray')))
   
    if(this.navParams.get('pageName') == 'edit'){
        
      this.navParams.get('materialListArray').forEach((v,k) => {
        this.productName = v.productName;
        this.total = v.totalAmt;
        //this.unit = this.navParams.get('materialListArray').perUnitRate
        this.custRate = v.perUnitRate;
        this.notes = v.notes;
        this.materialId = v.materialId;
        this.quantity = v.quantity;
        this.checked = v.checked;
        this.productNameList.push(this.productName);
        console.log(this.productNameList)
        this.disabled = true;
       });

       
       console.log(this.productNameList)
     }else{
        this.productNameList = [
          'Product One','Product Two','Product Three','Product Four'
       ];
     }
    
    this.rateList = [
      '12000','15000','10000'
    ];

   this.unitList = [
    'Hundreds','Thousands','Lacs','Crore'
   ];
    
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddMaterialPage');
  }

  gotoaddMateriallist() {
    console.log(this.perUnitRate)
    this.data = {
      materialId: this.materialId,
      productName: this.productName,
      quantity: this.quantity,
      discount: this.discount,
      totalAmt: this.total,
      perUnitRate: this.perUnitRate,
      notes: this.notes
    }
    console.log(this.data)

    this.saveMaterialToQuotationData.push(this.data); 
    if(this.materialId == '' || this.materialId == undefined
      //|| this.productName == '' || this.productName == undefined
      || this.quantity == '' || this.quantity == undefined
      || this.discount == '' || this.discount == undefined
      || this.perUnitRate == '' || this.perUnitRate == undefined
      || this.notes == '' || this.notes == undefined
     ){
      let toast = this.toastCtrl.create({
        message: 'Please fill all fields !',
        duration: 2000,
        position: 'top'
      });
      toast.present();
     }else{
         
          let toast = this.toastCtrl.create({
            message: 'Added successfully !',
            duration: 2000,
            position: 'top'
          });
          toast.present();
  
          if(this.navParams.get('pageName') == 'edit'){
            
            this.events.publish('event-saveMaterialToQuotationData', this.saveMaterialToQuotationData);
            this.navCtrl.pop();
      
          }else{
      
            this.navCtrl.push(AddMaterialListPage, {productData: this.saveMaterialToQuotationData});
            
            this.materialId =  '';
            this.productName =  '';
            this.quantity =  '';
            //unit: this.unit;
            this. total =  '';
            this.perUnitRate = '';
            this.notes =  '';
            this.custRate = '';
            this.rate = '';
            this.discount = '';
        }
     } 

 }
  gotoProductlist()
  {
   
    //this.navCtrl.push(ProductListPage);
  }

  getProductName(productName){
      console.log(productName)
      
  }

  getRate(rate){
      console.log(rate.split('/')[0]);
      this.perUnitRate = rate.split('/')[0];
      this.total = this.quantity * rate.split('/')[0];
     
  }

  getCustRate(rate){
    console.log(rate);
    this.perUnitRate = rate;
    this.total = this.quantity * rate;
   
  }

  getUnit(unit){
    console.log(unit)
  }


}
