import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,  LoadingController, Loading, ToastController, Events  } from 'ionic-angular';
import { ListPage } from '../list/list';

import { ApiService } from '../../api-services/api.services';
import { AddUpdateQuotePage } from '../add-update-quote/add-update-quote';

@IonicPage()
@Component({
  selector: 'page-add-material-list',
  templateUrl: 'add-material-list.html',
})
export class AddMaterialListPage {
  materialId: any;
  productNameList: any = [];
  rateList: any = [];
  unitList: any = [];

  custRate:any;
  quantity:any;
  notes:any;
  productName:any;
  rate:any;
  unit:any;

  loading: Loading;
  loadingConfig: any;
  total: any;
  perUnitRate: any;
  data: any;
  discount: any;

  saveMaterialToQuotationData:any = [];

  constructor(public navCtrl: NavController, public events: Events, public navParams: NavParams, private loadingCtrl: LoadingController, public apiServices: ApiService, private toastCtrl: ToastController,) {

    console.log(this.navParams.get('productData'));
    this.materialId = Math.random().toString(36).substr(2, 9);
    console.log(this.materialId);
   
    this.productNameList = [
       'Product One','Product Two','Product Three','Product Four'
    ];

    this.rateList = [
      '12000','15000','10000'
    ];

   this.unitList = [
    'Hundreds','Thousands','Lacs','Crore'
   ];

  }

  getProductName(productName){
    console.log(productName)
  }

  getRate(rate){
    console.log(rate.split('/')[0])
    this.perUnitRate = rate.split('/')[0];
    this.total = this.quantity * rate.split('/')[0];
  }

getCustRate(rate){
  console.log(rate)
  this.perUnitRate = rate;
  this.total = this.quantity * rate;
 
}

  getUnit(unit){
    console.log(unit)
  }

  saveMaterialToQuotation(){
    
    console.log(this.perUnitRate)

    this.data = {
      materialId: this.materialId,
      productName: this.productName,
      quantity: this.quantity,
      discount: this.discount,
      totalAmt: this.total,
      perUnitRate: this.perUnitRate,
      notes: this.notes
    }
    console.log(this.data)
    this.saveMaterialToQuotationData = this.navParams.get('productData');
    this.saveMaterialToQuotationData.push(this.data);
    console.log(this.saveMaterialToQuotationData)

     if(this.materialId == '' || this.materialId == undefined
      //|| this.productName == '' || this.productName == undefined
      || this.quantity == '' || this.quantity == undefined
      || this.discount == '' || this.discount == undefined
      || this.perUnitRate == '' || this.perUnitRate == undefined
      || this.notes == '' || this.notes == undefined
     ){
      let toast = this.toastCtrl.create({
        message: 'Please fill all fields !',
        duration: 2000,
        position: 'top'
      });
      toast.present();
     }else{
         
          let toast = this.toastCtrl.create({
            message: 'Added successfully !',
            duration: 2000,
            position: 'top'
          });
          toast.present();
      
          this.materialId = Math.random().toString(36).substr(2, 9);
          this.productName =  '';
          this.quantity =  '';
          //unit: this.unit;
          this. total =  '';
          this.perUnitRate = '';
          this.notes =  '';
          this.custRate = '';
          this.rate = '';
          this.discount = '';
     }
    
  }

createLoader(message: string = "Please wait...") { // Optional Parameter
  this.loading = this.loadingCtrl.create({
    content: message
  });
}

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddMaterialListPage');
  }

  cancelPage(){
    console.log(this.saveMaterialToQuotationData)
    if(this.saveMaterialToQuotationData == '' || this.saveMaterialToQuotationData == undefined){
      this.saveMaterialToQuotationData = this.navParams.get('productData');
    }
    console.log(this.saveMaterialToQuotationData)
    //this.navCtrl.push(AddUpdateQuotePage,{saveMaterialToQuotationData: this.saveMaterialToQuotationData})
    this.events.publish('event-saveMaterialToQuotationData', this.saveMaterialToQuotationData);
    this.navCtrl.pop();
  }
 
}
