import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Loading, LoadingController, ToastController, Events } from 'ionic-angular';
import { ApiService } from '../../api-services/api.services';

@IonicPage()
@Component({
  selector: 'product-list-page',
  templateUrl: 'product-list-page.html',
})
export class ProductListPage {
  
  getAllCategories: any = [];
  showLevel1 = null;
  showLevel2 = null;
  productCategoryList: any = [];
  productCategoryListNew: any = [];
  productsList: any = [];
  productsListData: any = [];
  loading: Loading;
  loadingConfig: any;

  subCategories: any =[];
  sub_Sub_Categories: any =[];
  productsListDataSubCat: any = [];
  productsListDataCat: any = [];

  constructor(public navCtrl: NavController, public navParams: NavParams, private toastCtrl: ToastController,public events: Events, private loadingCtrl: LoadingController, public apiServices: ApiService) {
    
    this.createLoader();
    this.loading.present().then(() => {
    this.apiServices.getAllCategoryList()
          .subscribe(response => {
            this.loading.dismiss();
            this.getAllCategories = Array.of(response);
            
            this.getAllCategories.forEach((v,k) => {
              this.productCategoryListNew = v.productCategoryList;
              this.productCategoryListNew.forEach((v1,k1) => {
                  if(v1.parentCategoryId == ""){
                    this.productCategoryList.push(v1);
                  }
              });
            });
            
          });
    }, error => {
            this.loading.dismiss();
            //this.errorMessage = <any>error
    });

   console.log(this.productCategoryList)
 
  }

  getSubCategories(id){
      console.log(id);
      this.subCategories = [];
      this.productCategoryListNew.forEach((v,k) => {
         
            if(v.parentCategoryId == id){
                this.subCategories.push(v);
            }
        
      });
       console.log(this.subCategories)
       if(this.subCategories.length == 0){
        console.log(id);
        this.getProducts(id);
    }
  }
  getSub_Sub_Categories(id){
      console.log(id);
      this.sub_Sub_Categories = [];
      this.productCategoryListNew.forEach((v,k) => {
         
            if(v.parentCategoryId == id){
                this.sub_Sub_Categories.push(v);
            }
        
      });
       console.log(this.sub_Sub_Categories)
       if(this.sub_Sub_Categories.length == 0){
           console.log(id);
           this.getProducts(id);
       }
  }

  toggleLevel1(idx) {
    if (this.isLevel1Shown(idx)) {
      this.showLevel1 = null;
    } else {
      this.showLevel1 = idx;
    }
  };
  
  toggleLevel2(idx) {
    if (this.isLevel2Shown(idx)) {
      this.showLevel1 = null;
      this.showLevel2 = null;
    } else {
      this.showLevel1 = idx;
      this.showLevel2 = idx;
    }
  };

  isLevel1Shown(idx) {
    return this.showLevel1 === idx;
  };
  
  isLevel2Shown(idx) {
    return this.showLevel2 === idx;
  };
  
  itemSelected(item: string) {
      console.log("Selected Item", item);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddMaterialPage');
  }

  getProducts(id){
        console.log("==="+ id);
        this.productsListData = [];
        this.productsListDataCat = [];
        this.productsListDataSubCat = [];

        this.createLoader();
        this.loading.present().then(() => {
        this.apiServices.getProductsByCatId(id)
              .subscribe(response => {
                this.loading.dismiss();
                this.productsListData = response.productsList;
                this.productsListDataCat = response.productsList;
                this.productsListDataSubCat = response.productsList;
                console.log(this.productsListData);
                /*if(this.productsListData == ''){
                  this.productsList.push(parentCategoryName);
                }else{
                  this.productsList.push(this.productsListData.productName);
                }*/
              }, error => {
                this.loading.dismiss();
                //this.errorMessage = <any>error
              });
        });
  }

  

 createLoader(message: string = "Please wait...") {
  this.loading = this.loadingCtrl.create({
    content: message
  });
}



}
