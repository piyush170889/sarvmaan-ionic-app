import { Component, NgModule } from '@angular/core';
import { NavController, NavParams, LoadingController, Loading, ToastController, Events, AlertController  } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SelectSearchable } from 'ionic-select-searchable';

import { MapsAPILoader } from '@agm/core';
import {} from '@types/googlemaps';
import { ViewChild, ElementRef, NgZone } from '@angular/core';

import { ApiService } from '../../api-services/api.services';

import { AddMaterialPage } from '../add-material/add-material';
import { AddMaterialListPage } from '../add-material-list/add-material-list';
import { HomePage } from '../home/home';

import { SQLite, SQLiteObject } from '@ionic-native/sqlite';

class State {
  public id: number;
  public displayText: string;
}
class City {
  public id: number;
  public displayText: string;
}

@Component({
  selector: 'page-add-update-quote',
  templateUrl: 'add-update-quote.html',
})
export class AddUpdateQuotePage {
  
  public addQuoteForm: FormGroup;
  states: State[];
  state: State;
  cities: City[];
  city: City;
  loading: Loading;
  loadingConfig: any;
  cityName: any;
  stateName: any;
  addtQuotationDetailData:any = [];
  materialList:any = [];
  saveMaterialToQuotationData:any = [];
  totalAmount: any;
  discount: any;
  grandTotal: any;
  quoteType: any;
  quoteStatus: any;
  paymentSchedule: any = [];

  materialListNEW:any = [];
  selectedValue: any = [];

  selectedMaterialID : any;
 

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private _FORMBUILDER: FormBuilder,
    private mapsAPILoader: MapsAPILoader,
    private ngZone: NgZone,
    private loadingCtrl: LoadingController,
    private toastCtrl: ToastController,
    public apiServices: ApiService,
    public events: Events,
    public alertCtrl: AlertController,
    private sqlite: SQLite
  ) {
    this.addQuoteForm = this._FORMBUILDER.group({
      'quoteNumber': ['', [Validators.required]],
      'workTitle': ['', [Validators.required]],
      'clientName': ['', [Validators.required]],
      'contactNo': ['', [Validators.required]],
      'streetAddress': ['', [Validators.required]],
      'state': ['', [Validators.required]],
      'city': ['', [Validators.required]],
      'tnc': ['', [Validators.required]],
      'total': ['', ''],
      'discount': ['', ''],
      'grandTotal': ['', ''],
      'productSts': ['','']    
    });
    
    this.saveMaterialToQuotationData = [];
    this.materialList = [];
    this.addQuoteForm.controls['total'].setValue(0);
    this.addQuoteForm.controls['discount'].setValue(0);
    this.addQuoteForm.controls['grandTotal'].setValue(0);
    
    
    this.createLoader();
    this.loading.present().then(() => {
      this.apiServices.getStatesAndCities().subscribe((response) => {
        this.loading.dismiss();
        this.states = response.locationDtlsTo.stateDtls;	
        this.cities = response.locationDtlsTo.cityDtls;
      }, (err) => {
        this.loading.dismiss();
      })
    })

    events.subscribe('event-saveMaterialToQuotationData', (data) => {
     
      this.saveMaterialToQuotationData =  data;
      console.log(this.saveMaterialToQuotationData)

      this.totalAmount = 0;
      this.discount = 0;
      this.grandTotal = 0;
      this.addQuoteForm.controls['productSts'].setValue('false');

      this.materialList = [];

      if(this.saveMaterialToQuotationData == undefined){
          this.saveMaterialToQuotationData = [];
      }

      this.materialList =  this.saveMaterialToQuotationData;
     

      //try if not then try with select query and then do calc
      
      this.materialList.forEach((v,k) => {
        //alert(parseInt(v.totalAmt) +"=="+ parseInt(v.discount))
        this.totalAmount =  parseInt(this.totalAmount) + parseInt(v.totalAmt);
        //this.discount =   parseInt(this.discount) + parseInt(v.discount);
        //this.grandTotal = parseInt(this.totalAmount) - parseInt(this.discount);
        
        this.addQuoteForm.controls['total'].setValue(this.totalAmount);
        this.addQuoteForm.controls['discount'].setValue(0);
        this.addQuoteForm.controls['grandTotal'].setValue(this.totalAmount);
      });


    
    });

      
 }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddUpdateQuotePage');
  }

  stateChange(event: { component: SelectSearchable, value: any }) {
    this.stateName = event.value.stateName;
  }
  cityChange(event: { component: SelectSearchable, value: any }) {
    this.cityName = event.value.cityName;
  }
    
  createLoader(message: string = "Please wait...") { // Optional Parameter
    this.loading = this.loadingCtrl.create({
      content: message
    });
  }

  addMaterialToQuotationPage(){
    this.navCtrl.push(AddMaterialPage);
  }

  submitQuotation(){
    
    this.quoteStatus = '';

     if(
       this.addQuoteForm.controls['workTitle'].value == '' || this.addQuoteForm.controls['workTitle'].value == undefined ||
       this.addQuoteForm.controls['clientName'].value == '' || this.addQuoteForm.controls['clientName'].value == undefined ||
       this.addQuoteForm.controls['contactNo'].value == '' || this.addQuoteForm.controls['contactNo'].value == undefined ||
       this.addQuoteForm.controls['tnc'].value == '' || this.addQuoteForm.controls['tnc'].value == undefined 
     ){
      let toast = this.toastCtrl.create({
        message: 'Please fill all fields !',
        duration: 3000,
        position: 'top'
      });
      toast.present();
    }else{
      let confirm = this.alertCtrl.create({
        title: '',
        message: 'Select Quotation Type',
        buttons: [
          {
            text: 'Sarvmaan',
            handler: () => {
                this.quoteType = 'SARVMAAN';
                this.sendQuotation(this.quoteType, this.quoteStatus);
            }
          },
          {
            text: 'Customer',
            handler: () => {
              this.quoteType = 'SELF';
              this.sendQuotation(this.quoteType, this.quoteStatus);
            }
          }
        ]
      });
      confirm.present();
    }

   }

  sendQuotation(quoteType, quoteStatus){
    console.log(JSON.stringify(this.materialList));
   

    let data = {
      "quoteNumber": this.addQuoteForm.controls['quoteNumber'].value,
      "workTitle": this.addQuoteForm.controls['workTitle'].value,
      "clientName": this.addQuoteForm.controls['clientName'].value,
      "contactNumber": this.addQuoteForm.controls['contactNo'].value, 
      "address": [
        {
          "cityName": this.cityName,
          "stateName": this.stateName,
          "countryName": "India",
          "street": this.addQuoteForm.controls['streetAddress'].value
        }
      ],
      "termsAndCondition":this.addQuoteForm.controls['tnc'].value,
      "emailId":"piyushtestupdated@gmail.com",
      "quoteStatus": quoteStatus,    //quote Status will be DRAFT quote is saved as DRAFT. If                    // it is submitted than leave this field empty
      "quoteType": quoteType, //SELF/SARVMAAN
      "grandTotal": this.addQuoteForm.controls['grandTotal'].value,
      "totalAmount": this.addQuoteForm.controls['total'].value,
      "discount": this.addQuoteForm.controls['discount'].value,

      "materialList":  this.materialList,
      "paymentSchedule": this.paymentSchedule
    }

    console.log(data)
    this.createLoader();
     this.loading.present().then(() => {
     this.apiServices.addtQuotationDetail(data)
          .subscribe(response => {
            this.loading.dismiss();
            this.addtQuotationDetailData = response.quotationDtls;
            this.navCtrl.setRoot(HomePage);
          }, error => {
            this.loading.dismiss();
            //this.errorMessage = <any>error
          });
    });
  }

  saveQuotationAsDraft(){
    
    this.quoteStatus = 'DRAFT';

    if(this.addQuoteForm.controls['workTitle'].value == '' || this.addQuoteForm.controls['workTitle'].value == undefined ||
    this.addQuoteForm.controls['clientName'].value == '' || this.addQuoteForm.controls['clientName'].value == undefined ||
    this.addQuoteForm.controls['contactNo'].value == '' || this.addQuoteForm.controls['contactNo'].value == undefined ||
    this.addQuoteForm.controls['tnc'].value == '' || this.addQuoteForm.controls['tnc'].value == undefined 
    ){
      let toast = this.toastCtrl.create({
        message: 'Please fill all fields !',
        duration: 3000,
        position: 'top'
      });
      toast.present();
    }else{
      let confirm = this.alertCtrl.create({
        title: '',
        message: 'Select Quotation Type',
        buttons: [
          {
            text: 'Sarvmaan',
            handler: () => {
                this.quoteType = 'SARVMAAN';
                this.sendQuotation(this.quoteType, this.quoteStatus);
            }
          },
          {
            text: 'Customer',
            handler: () => {
              this.quoteType = 'SELF';
              this.sendQuotation(this.quoteType, this.quoteStatus);
            }
          }
        ]
      });
      confirm.present();
    }
  }

  cancelPage(){
   
     this.navCtrl.setRoot(HomePage);
  }

  checkboxChange(data){
   console.log(data);
   console.log(this.materialList);
  

   if(this.addQuoteForm.controls['productSts'].value == true){
        /*this.selectedValue.push({
            'materialId': data.materialId,
            'productName': data.productName,
            'notes': data.notes,
            'quantity': data.quantity,
            'perUnitRate': data.perUnitRate,
            'totalAmt': data.totalAmt,
            'productId': data.productId,
            'checked': 'true',
        });*/

        this.selectedMaterialID = data.materialId;
        //alert(this.selectedMaterialID);

        this.sqlite.create({
          name: 'materialDb.db',
          location: 'default'
        }).then((db: SQLiteObject) => {

          db.executeSql('INSERT INTO materialList VALUES(NULL,?,?,?,?,?,?,?,?,?)',[data.materialId,data.productName,data.notes,data.quantity,data.perUnitRate,data.totalAmt,data.productId,'true',data.discount])
          .then(res => {
            //alert("insert_2=="+JSON.stringify(res));
            //alert('saved');
          });

         

        });
   }
   
 /*  console.log(
           '==materialId=='+data.materialId
         + '==productName=='+data.productName
         + '==notes=='+data.notes
         + '==quantity==' +data.quantity
         + '==perUnitRate==' +data.perUnitRate
         + '==totalAmt==' +data.totalAmt
         + '==productId=='+data.productId
         + '==checked=='+data.checked
    )

    if(this.addQuoteForm.controls['productSts'].value == true){

      this.sqlite.create({
        name: 'materialDb.db',
        location: 'default'
      }).then((db: SQLiteObject) => {
  
       // this.materialList.forEach((v,k) => {
  
      db.executeSql('INSERT INTO materialList VALUES(NULL,?,?,?,?,?,?,?,?)',[data.materialId,data.productName,data.notes,data.quantity,data.perUnitRate,data.totalAmt,data.productId,'true'])
      .then(res => {
        //alert("insert=="+JSON.stringify(res));
        //alert('saved');
      });
  
       // });
       
       db.executeSql('SELECT * FROM materialList ORDER BY rowid DESC', {})
        .then(res => {
          //alert("select=="+JSON.stringify(res));
          this.materialListNEW = [];
          for(var i=0; i<res.rows.length; i++) {
              this.materialListNEW.push({
                    rowid:res.rows.item(i).rowid,
                    materialId:res.rows.item(i).materialId,
                    productName:res.rows.item(i).productName,
                    notes:res.rows.item(i).notes,
                    quantity:res.rows.item(i).quantity,
                    perUnitRate:res.rows.item(i).perUnitRate,
                    totalAmt:res.rows.item(i).totalAmt,
                    productId:res.rows.item(i).productId,
                    checked:res.rows.item(i).checked
              })
          }

        })

  
      });

    }
*/

    
   // this.materialListNEW = this.materialList;
   // console.log(this.materialListNEW);
    
    //this.materialListNEW = [];
   /* if(this.addQuoteForm.controls['productSts'].value == true){
      this.materialList.forEach((v,k) => {
        if(materialId == v.materialId){
         
          this.materialListNEW.push({
            'materialId': v.materialId,
            'productName' : v.productName,
            'notes' : v.notes,
            'quantity' : v.quantity,
            'perUnitRate' : v.perUnitRate,
            'totalAmt' : v.totalAmt,
            'productId': v.productId,
            'checked': 'true'
          });

        }
      });
    }else{
      this.materialListNEW.splice(this.materialListNEW.indexOf(materialId));
        
     
    }*/

   
         

       
   

   /* this.materialList.forEach((v,k) => {
      
      if(this.addQuoteForm.controls['productSts'].value == true){
            console.log('true');
            if(materialId == v.materialId){
              this.materialListNEW.push({
                'materialId': materialId,
              });
            }
             
        }
       
    });*/
    
  }

  removeMaterialToQuotationPage(){
    
    this.sqlite.create({
      name: 'materialDb.db',
      location: 'default'
    }).then((db: SQLiteObject) => {
    
          db.executeSql('SELECT DISTINCT materialId, productName, notes, quantity, perUnitRate, totalAmt, productId, checked, discount FROM materialList ORDER BY rowid DESC', {})
        .then(res => {
        
            this.materialList = [];
            for(var i=0; i<res.rows.length; i++) {
                
                  if(res.rows.item(i).checked == 'true'){
                    
                   /* alert("1=="+res.rows.item(i).materialId+"=="
                    +res.rows.item(i).productName+"=="
                    +res.rows.item(i).checked)*/
                    db.executeSql('DELETE FROM materialList WHERE materialId = ?',[res.rows.item(i).materialId])
                    .then(res => {
                        //alert("delete=="+JSON.stringify(res));     
                    });

                  }

          }

                db.executeSql('SELECT DISTINCT materialId, productName, notes, quantity, perUnitRate, totalAmt, productId, checked, discount FROM materialList ORDER BY rowid DESC', {})
            .then(res => {
              //alert("select=="+JSON.stringify(res));
            // this.materialListNEW = [];
              for(var i=0; i<res.rows.length; i++) {
                  this.materialList.push({
                        rowid:res.rows.item(i).rowid,
                        materialId:res.rows.item(i).materialId,
                        productName:res.rows.item(i).productName,
                        notes:res.rows.item(i).notes,
                        quantity:res.rows.item(i).quantity,
                        perUnitRate:res.rows.item(i).perUnitRate,
                        totalAmt:res.rows.item(i).totalAmt,
                        productId:res.rows.item(i).productId,
                        checked:res.rows.item(i).checked,
                        discount:res.rows.item(i).discount
                  })
              }

            })

        })

   
  });
      
  }

  EditMaterialToQuotationPage(){
    //alert(this.selectedMaterialID);
    //alert("materialList==="+JSON.stringify(this.materialList));
    
     this.materialList.forEach((v,k) => {
      
        if(this.addQuoteForm.controls['productSts'].value == true){
              console.log('true');
              if(this.selectedMaterialID == v.materialId){
                //alert("materialList333==="+JSON.stringify(this.materialList));
                 this.navCtrl.push(AddMaterialPage,
                      {'pageName':'editMaterialLocally',
                        materialListArray:this.materialList,
                        selectedMaterialID: this.selectedMaterialID
                  });
              }
               
          }
         
      });
     
}

getTotalAmount(){

  this.discount = this.addQuoteForm.controls['discount'].value;
  this.addQuoteForm.controls['discount'].setValue(this.discount);

  this.grandTotal = this.addQuoteForm.controls['total'].value - this.discount;
  this.addQuoteForm.controls['grandTotal'].setValue(this.grandTotal);
  
  console.log(this.totalAmount);
  console.log(this.discount);
  console.log(this.grandTotal);

  //this.addQuoteForm.controls['discount'].setValue(this.discount);
  
  //this.grandTotal = parseInt(this.addQuoteForm.controls['total'].value) - parseInt(this.discount)
  //this.addQuoteForm.controls['grandTotal'].setValue(this.grandTotal);
 
   // this.grandTotal = parseInt(this.totalAmount) - parseInt(this.discount);
} 

}
