import { Component } from '@angular/core';
import { NavController, LoadingController, Loading } from 'ionic-angular';
import { ApiService } from '../../api-services/api.services';
import { AddUpdateQuotePage } from '../../pages/add-update-quote/add-update-quote';
import { QuotationDetailsPage } from '../../pages/quotation-details/quotation-details';

import { SQLite, SQLiteObject } from '@ionic-native/sqlite';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  loading: Loading;
  loadingConfig: any;
  quoteListCustomer:any = []; 
  allQuoteList:any = []; 
  sarvmaanTab:boolean = false;
  showsearchbar: boolean = false;
  searchTerm: string = '';
  searchStatus:number = 1;

  page:any = 0;
  quoteListCust:any = [];
  quoteListSarv:any = [];
  quoteListSarvmaan:any = [];
  pageSarv:any = 0;
  

  constructor(
    public navCtrl: NavController, 
    private loadingCtrl: LoadingController, 
    public apiServices: ApiService,
    private sqlite: SQLite
  ) {
    this.sarvmaanTab = false;
    
    
   this.sqlite.create({
      name: 'materialDb.db',
      location: 'default'
    }).then((db: SQLiteObject) => {
     
      db.executeSql('SELECT DISTINCT materialId, productName, notes, quantity, perUnitRate, totalAmt, productId, checked, discount FROM materialList ORDER BY rowid DESC', {})
      .then(res => {
      
          for(var i=0; i<res.rows.length; i++) {
              db.executeSql('DELETE FROM materialList WHERE materialId = ?',[res.rows.item(i).materialId])
                  .then(res => {
                      //alert("delete=="+JSON.stringify(res));     
               });
          }

      });

    });
    
  }

  sarvmanTabClicked(){
    this.sarvmaanTab = true;
    this.searchStatus = 2;
    this.getsarvmanListSarv();
  }

  customerTabClicked(){
    this.sarvmaanTab= false;
    this.searchStatus = 1;
    this.getsarvmanList();
  }

  getsarvmanList(){
    this.page = 0;
    this.quoteListCustomer = [];
    this.createLoader();
    this.loading.present().then(() => {
    this.apiServices.getSarvamList(this.page)
         .subscribe(response => {
           this.allQuoteList = response;
           this.quoteListCustomer = response.selfQuotationDtlsList;
           this.sarvmaanTab= false;
           this.loading.dismiss();
         }, error => {
           this.loading.dismiss();
           //this.errorMessage = <any>error
         });
   });
  }
  getsarvmanListSarv(){
    this.pageSarv = 0;
    //this.quoteList = [];
    this.createLoader();
    this.loading.present().then(() => {
    this.apiServices.getSarvamList(this.pageSarv)
         .subscribe(response => {
           this.allQuoteList = response;
           this.quoteListSarvmaan = response.sarvMaanQuotationDtlsList;
           this.sarvmaanTab= true;
           this.loading.dismiss();
         }, error => {
           this.loading.dismiss();
           //this.errorMessage = <any>error
         });
   });
  }

  createLoader(message: string = "Please wait...") { // Optional Parameter
    this.loading = this.loadingCtrl.create({
      content: message
    });
  }
  
  ionViewDidLoad() {   
    this.createLoader(); 
    this.getsarvmanList();
  }

  
  
  addNewQuote(){
    this.navCtrl.push(AddUpdateQuotePage);
  }

  goToQuotationDetailsPage(id){
    this.navCtrl.push(QuotationDetailsPage, {id:id});
  }
  
  opensearchbox()
  {
    this.showsearchbar = !this.showsearchbar;
  }

  setFilteredItems(ev: any) {
 
    if(this.searchStatus == 2){
      this.pageSarv = 0;
      this.apiServices.getSarvamList(this.pageSarv)
    .subscribe(response => {
      this.allQuoteList = response;
      this.quoteListSarvmaan = response.sarvMaanQuotationDtlsList;
      let val = ev.target.value;
      console.log(JSON.stringify(val));
        if (val && val.trim() != '') {
          this.quoteListSarvmaan = this.quoteListSarvmaan.filter((item) => {
            return (item.workTitle.toLowerCase().indexOf(val.toLowerCase()) > -1 || item.clientName.toLowerCase().indexOf(val.toLowerCase()) > -1 );
          })
        } 

      }, error => {
     //this.errorMessage = <any>error
    });

   }else{
      this.page = 0;
      this.apiServices.getSarvamList(this.page)
    .subscribe(response => {
      this.allQuoteList = response;
      this.quoteListCustomer = response.selfQuotationDtlsList;
      let val = ev.target.value;
      console.log(JSON.stringify(val));
        if (val && val.trim() != '') {
          this.quoteListCustomer = this.quoteListCustomer.filter((item) => {
            return (item.workTitle.toLowerCase().indexOf(val.toLowerCase()) > -1 || item.clientName.toLowerCase().indexOf(val.toLowerCase()) > -1 );
          })
        } 
      }, error => {
     //this.errorMessage = <any>error
    });

  }
}


doInfinite(infiniteScroll) {
 
    if(this.searchStatus == 1){
     
      this.page = this.page + 1;
 
      setTimeout(() => {
        this.apiServices.getSarvamList(this.page)
        .subscribe(response => {
          this.allQuoteList = response;
          this.quoteListCust = response.selfQuotationDtlsList;
          
          for(let i=0; i<this.quoteListCust.length; i++) {
            this.quoteListCustomer.push(this.quoteListCust[i]);
          }

        }, error => {
          this.loading.dismiss();
          //this.errorMessage = <any>error
        });

          
      infiniteScroll.complete();
      //infiniteScroll.enable(false);

      }, 500);

    }else if(this.searchStatus == 2){
     
      this.pageSarv = this.pageSarv + 1;
     
      setTimeout(() => {
        this.apiServices.getSarvamList(this.pageSarv)
        .subscribe(response => {
          this.allQuoteList = response;
          
          this.quoteListSarv = response.sarvMaanQuotationDtlsList;
           
          for(let i=0; i<this.quoteListSarv.length; i++) {
            this.quoteListSarvmaan.push(this.quoteListSarv[i]);
          }
        

        }, error => {
          this.loading.dismiss();
          //this.errorMessage = <any>error
        });

          
      infiniteScroll.complete();
      //infiniteScroll.enable(false);

      }, 500);

    }else{
      infiniteScroll.enable(false);
    }

  } 

}
