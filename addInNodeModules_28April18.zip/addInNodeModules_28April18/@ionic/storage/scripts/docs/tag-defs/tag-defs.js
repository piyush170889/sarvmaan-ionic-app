module.exports = [
  {'name': 'advanced'},
  {'name': 'demo'},
  {'name': 'usage'},
  {'name': 'hidden'}, // hide from docs
];
