<a style="float:right;font-size:12px;" href="http://github.com/ionic-team/ionic-native/edit/master/src/@ionic-native/plugins/sim/index.ts#L1">
  Improve this doc
</a>

# Sim

```
$ ionic cordova plugin add cordova-plugin-sim
$ npm install --save @ionic-native/sim
```

## [Usage Documentation](https://ionicframework.com/docs/native/sim/)

Plugin Repo: [https://github.com/pbakondy/cordova-plugin-sim](https://github.com/pbakondy/cordova-plugin-sim)

Gets info from the Sim card like the carrier name, mcc, mnc and country code and other system dependent info.

Requires Cordova plugin: `cordova-plugin-sim`. For more info, please see the [Cordova Sim docs](https://github.com/pbakondy/cordova-plugin-sim).

## Supported platforms
- Android
- iOS
- Windows
- Windows Phone



