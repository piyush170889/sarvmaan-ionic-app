<a style="float:right;font-size:12px;" href="http://github.com/ionic-team/ionic-native/edit/master/src/@ionic-native/plugins/device/index.ts#L3">
  Improve this doc
</a>

# Device

```
$ ionic cordova plugin add cordova-plugin-device
$ npm install --save @ionic-native/device
```

## [Usage Documentation](https://ionicframework.com/docs/native/device/)

Plugin Repo: [https://github.com/apache/cordova-plugin-device](https://github.com/apache/cordova-plugin-device)

Access information about the underlying device and platform.

## Supported platforms
- Android
- Browser
- iOS
- macOS
- Windows



