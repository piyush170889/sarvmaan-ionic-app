<a style="float:right;font-size:12px;" href="http://github.com/ionic-team/ionic-native/edit/master/src/@ionic-native/plugins/keyboard/index.ts#L2">
  Improve this doc
</a>

# Keyboard

```
$ ionic cordova plugin add ionic-plugin-keyboard
$ npm install --save @ionic-native/keyboard
```

## [Usage Documentation](https://ionicframework.com/docs/native/keyboard/)

Plugin Repo: [https://github.com/ionic-team/ionic-plugin-keyboard](https://github.com/ionic-team/ionic-plugin-keyboard)



## Supported platforms
- Android
- BlackBerry 10
- iOS
- Windows



