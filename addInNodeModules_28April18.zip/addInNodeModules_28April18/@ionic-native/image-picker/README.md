<a style="float:right;font-size:12px;" href="http://github.com/ionic-team/ionic-native/edit/master/src/@ionic-native/plugins/image-picker/index.ts#L28">
  Improve this doc
</a>

# Image Picker

```
$ ionic cordova plugin add cordova-plugin-telerik-imagepicker --variable PHOTO_LIBRARY_USAGE_DESCRIPTION="your usage message"
$ npm install --save @ionic-native/image-picker
```

## [Usage Documentation](https://ionicframework.com/docs/native/image-picker/)

Plugin Repo: [https://github.com/Telerik-Verified-Plugins/ImagePicker](https://github.com/Telerik-Verified-Plugins/ImagePicker)

Cordova Plugin For Multiple Image Selection

Requires Cordova plugin: `cordova-plugin-image-picker`.
For more info, please see the https://github.com/wymsee/cordova-imagePicker

## Supported platforms
- Android
- iOS



