<a style="float:right;font-size:12px;" href="http://github.com/ionic-team/ionic-native/edit/master/src/@ionic-native/plugins/sqlite/index.ts#L139">
  Improve this doc
</a>

# SQLite

```
$ ionic cordova plugin add cordova-sqlite-storage
$ npm install --save @ionic-native/sqlite
```

## [Usage Documentation](https://ionicframework.com/docs/native/sqlite/)

Plugin Repo: [https://github.com/litehelpers/Cordova-sqlite-storage](https://github.com/litehelpers/Cordova-sqlite-storage)

Access SQLite databases on the device.

## Supported platforms
- Android
- iOS
- macOS
- Windows



