<a style="float:right;font-size:12px;" href="http://github.com/ionic-team/ionic-native/edit/master/src/@ionic-native/plugins/spinner-dialog/index.ts#L8">
  Improve this doc
</a>

# Spinner Dialog

```
$ ionic cordova plugin add cordova-plugin-native-spinner
$ npm install --save @ionic-native/spinner-dialog
```

## [Usage Documentation](https://ionicframework.com/docs/native/spinner-dialog/)

Plugin Repo: [https://github.com/greybax/cordova-plugin-native-spinner](https://github.com/greybax/cordova-plugin-native-spinner)



## Supported platforms
- Android
- iOS
- Windows Phone 8
- Windows



