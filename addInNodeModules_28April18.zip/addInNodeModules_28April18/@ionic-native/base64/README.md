<a style="float:right;font-size:12px;" href="http://github.com/ionic-team/ionic-native/edit/master/src/@ionic-native/plugins/base64/index.ts#L1">
  Improve this doc
</a>

# Base64
  <p style="color:orange">
    This plugin is still in beta stage and may not work as expected. Please
    submit any issues to the <a target="_blank"
    href="/issues">plugin repo</a>.
  </p>


```
$ ionic cordova plugin add com-badrit-base64
$ npm install --save @ionic-native/base64
```

## [Usage Documentation](https://ionicframework.com/docs/native/base64/)

Plugin Repo: [https://github.com/hazemhagrass/phonegap-base64](https://github.com/hazemhagrass/phonegap-base64)

This Plugin is used to encode base64 of any file, it uses js code for iOS, but in case of android it uses native code to handle android versions lower than v.3

## Supported platforms
- Android
- iOS



