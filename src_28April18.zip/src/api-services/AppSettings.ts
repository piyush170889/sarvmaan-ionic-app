export class AppSettings {
    public static API_ENDPOINT='http://67.211.220.180:8080/sarvMaan-api/v1/';
 }